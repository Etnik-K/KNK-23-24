create definer = root@localhost trigger insert_into_profesor
    after insert
    on users
    for each row
BEGIN
    IF NEW.user_type = 'professor' THEN
        INSERT INTO profesor (id, firstName, lastName, faculty_id, lenda_id, is_approved)
        VALUES (new.id, NEW.firstName, NEW.lastName, NEW.faculty_id, NULL, NEW.is_approved);
    END IF;
END;

