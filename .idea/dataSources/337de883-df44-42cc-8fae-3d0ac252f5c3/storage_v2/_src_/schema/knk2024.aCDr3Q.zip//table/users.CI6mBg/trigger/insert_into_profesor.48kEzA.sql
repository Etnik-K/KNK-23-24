create definer = root@localhost trigger insert_into_profesor
    after insert
    on users
    for each row
begin
    if new.user_type = 'professor' then
        insert into profesor (firstName, lastName, faculty_id, is_approved)
        values (new.firstName, new.lastName, new.faculty_id, new.is_approved);
    end if;
end;

