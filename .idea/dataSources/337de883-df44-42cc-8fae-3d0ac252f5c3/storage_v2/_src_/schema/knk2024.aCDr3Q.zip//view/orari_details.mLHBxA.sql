create definer = root@localhost view orari_details as
select `o`.`id`           AS `orari_id`,
       `o`.`fakulteti_id` AS `fakulteti_id`,
       `f`.`faculty_name` AS `faculty_name`,
       `o`.`profesori_id` AS `profesori_id`,
       `p`.`firstName`    AS `professor_firstName`,
       `p`.`lastName`     AS `professor_lastName`,
       `o`.`lenda_id`     AS `lenda_id`,
       `l`.`lenda_name`   AS `lenda_name`,
       `o`.`salla_id`     AS `salla_id`,
       `s`.`salla_name`   AS `salla_name`,
       `o`.`time_slot_id` AS `time_slot_id`,
       `ts`.`day_of_week` AS `day_of_week`,
       `ts`.`start_time`  AS `start_time`,
       `ts`.`end_time`    AS `end_time`,
       `o`.`capacity`     AS `capacity`
from (((((`knk2024`.`orari` `o` left join `knk2024`.`fakulteti` `f`
          on ((`o`.`fakulteti_id` = `f`.`id`))) left join `knk2024`.`profesor` `p`
         on ((`o`.`profesori_id` = `p`.`id`))) left join `knk2024`.`lenda` `l`
        on ((`o`.`lenda_id` = `l`.`id`))) left join `knk2024`.`salla` `s`
       on ((`o`.`salla_id` = `s`.`id`))) left join `knk2024`.`timeslot` `ts` on ((`o`.`time_slot_id` = `ts`.`id`)));

