create definer = root@localhost view denied_users as
select `knk2024`.`users`.`id`           AS `id`,
       `knk2024`.`users`.`firstName`    AS `firstName`,
       `knk2024`.`users`.`lastName`     AS `lastName`,
       `knk2024`.`users`.`email`        AS `email`,
       `knk2024`.`users`.`salt`         AS `salt`,
       `knk2024`.`users`.`passwordHash` AS `passwordHash`,
       `knk2024`.`users`.`user_type`    AS `user_type`,
       `knk2024`.`users`.`faculty_id`   AS `faculty_id`,
       `knk2024`.`users`.`is_approved`  AS `is_approved`
from `knk2024`.`users`
where (`knk2024`.`users`.`is_approved` = false);

